#SOO JIUN GUAN
#TP068687

# main menu
def menu(): # create "menu()" function to enable user to choose his role
    while True: # create while loop(1) with "True" as the condition
        print("\n─────────────────Menu─────────────────\n") # display "\n─────────────────Menu─────────────────\n" string as main topic of "menu()" function
        print("What are your role?") # display "What are your role?" string as question 
        print("(1) >>>>>>>>>> You are an admin.") # display "(1) >>>>>>>>>> You are an admin." string as admin selection
        print("(2) >>>>>>>>>> You are a customer.") # display "(2) >>>>>>>>>> You are a customer." string as customer selection
        print("(3) >>>>>>>>>> Exit.") # display "(3) >>>>>>>>>> Exit." string as exit selection
        menu_option=input("Welcome to FRESHO, please type in your option: ") # use “input()” function with "Welcome to FRESHO, please type in your option: " string to ask user to input his selection and make it as "admin_username" variable
        if (menu_option=="1"): # if "menu_option" variable is filled in with "1" string, go to next step
            admin_login() # call "admin_login()" function
            break # use "break" function to completely terminate the while loop(1)
        elif (menu_option=="2"): # else if "menu_option" variable is filled in with "2" string, go to next step
            customer() # call "customer()" function
            break # use "break" function to completely terminate the while loop(1)
        elif (menu_option=="3"): # else if "menu_option" variable is filled in with "3" string, user will quit this program
             print("\nThank you for coming!") # display "\nThank you for coming!" string
             exit() # exit this program
             break # use "break" function to completely terminate the while loop(1)
        else: # else if "menu_option" variable is not filled in with "1" string or "2" string or "3" string, go to next step
            print("Invalid input!") # display "Invalid input!" string to remind user to choose valid option and restart the while loop(1)

# admin part

# admin login
def admin_login(): # create "admin_login()" function to enable admin login his account
    print("\n─────────────────Admin Login─────────────────\n") # display "\n─────────────────Admin Login─────────────────\n" string as main topic of "admin_login()" function
    admin_username=input("Please enter your admin username: ") # use “input()” function with "Please enter your admin username: " string to ask admin to input his admin username and make it as "admin_username" variable
    with open ("admin.txt","r") as read_admin_file: # use “with open ()” function to open "admin.txt" for reading and then automatically close the file, make it as "read_admin_file" variable 
        read=read_admin_file.readlines() # use “readlines()” function to read contents of "read_admin_file" variable line by line, put the read contents into a list and then make it as “read” variable
        for line in read: # use for loop and hold the value as "line" variable from "read" variable during the iteration
            if line.startswith ("username: "+admin_username+"\\"): # use startswith() function to find out the "line" variable that start with "username: " string + "admin_username" variable + "\\" string, if it was found, go to next step
                admin_password=input("Please enter your admin password: ") # use “input()” function with "Please enter your admin password: " string to ask admin to input his admin password and make it as "admin_password" variable
                if ("password: "+admin_password+"\\") in line: # if "password: " string + "admin_password" variable + "\\" string in "line" variable, go to next step
                    print("Successfully log in! Welcome back, "+admin_username+".") # display "Successfully log in! Welcome back, " string + "admin_username" variable + "." string as reminder that login success
                    admin_menu() # call "admin_menu()" function
    while True: # create a while loop(1) with "True" as the condition
        print("\nAccount doesn't exist or wrong password! Please ask other admin to create.") # display "\nAccount doesn't exist or wrong password! Please ask other admin to create." string as reminder that cannot login 
        print("(1) >>>>>>>>>> Log in again.") # display "(1) >>>>>>>>>> Log in again." string as continue selection
        print("(2) >>>>>>>>>> Back to main menu.") # display "(2) >>>>>>>>>> Back to main menu." string as terminate selection
        login_option=input("Enter your selection: ") # use “input()” function with "Enter your selection: " string to ask admin to input his selection and make it as "login_option" variable
        if (login_option=="1"): # if "login_option" variable is filled in with "1" string, go to next step
            admin_login() # call "admin_login()" function
            break # use "break" function to completely terminate the while loop(1)
        elif (login_option=="2"): # else if "login_option" variable is filled in with "2" string, go to next step
            menu() # call "menu()" function
            break # use "break" function to completely terminate the while loop(1)
        else: # else if "login_option" variable is not filled in with "1" string or "2" string, go to next step
            print("Please choose valid option!") # display "Please choose valid option!" string to remind admin to choose valid option and restart the while loop(1)

# admin menu
def admin_menu(): # create "admin_menu()" function to enable admin choose what he wants to do
    while True: # create while loop(1) with "True" as the condition
        print("\n─────────────────Admin─────────────────\n") # display "\n─────────────────Admin─────────────────\n" string as main topic of "admin_menu()" function
        print("(1) >>>>>>>>>> View all items.") # display "(1) >>>>>>>>>> View all items." string as view all items selection
        print("(2) >>>>>>>>>> Upload items.") # display "(2) >>>>>>>>>> Upload items." string as upload items selection
        print("(3) >>>>>>>>>> Edit items.") # display "(3) >>>>>>>>>> Edit items." string as edit items selection
        print("(4) >>>>>>>>>> Delete items.") # display "(4) >>>>>>>>>> Delete items." string as delete items selection
        print("(5) >>>>>>>>>> Search specific item.") # display "(5) >>>>>>>>>> Search items." string as search specific item selection
        print("(6) >>>>>>>>>> View all orders.") # display "(6) >>>>>>>>>> View all orders." string as view all orders selection
        print("(7) >>>>>>>>>> Search sepcific order.") # display "(7) >>>>>>>>>> Search sepcific customer's order." string as search specific order selection
        print("(8) >>>>>>>>>> Create new admin.") # display "(8) >>>>>>>>>> Create new admin." string as create new admin account selection
        print("(9) >>>>>>>>>> Log out.") # display "(9) >>>>>>>>>> Log out.\n" string as log out admin account selection
        admin_menu_option=input("Please choose your option: ") # use “input()” function with "Please choose your option: " string to ask admin to input his selection and make it as "admin_menu_option" variable
        if (admin_menu_option=="1"): # if ”admin_menu_option" variable is filled in with "1" string, go to next step
            admin_view_item() # call "admin_view_item()" function
            break # use "break" function to completely terminate the while loop(1)
        elif (admin_menu_option=="2"): # else if "admin_menu_option" variable is filled in with "2" string, go to next step
            upload_item() # call "upload_item()" function
            break # use "break" function to completely terminate the while loop(1)
        elif (admin_menu_option=="3"): # else if "admin_menu_option" variable is filled in with "3" string, go to next step
            edit_item() # call "edit_item()" function
            break # use "break" function to completely terminate the while loop(1)
        elif (admin_menu_option=="4"): # else if "admin_menu_option" variable is filled in with "4" string, go to next step
            delete_item() # call "delete_item()" function
            break # use "break" function to completely terminate the while loop(1)
        elif (admin_menu_option=="5"): # else if "admin_menu_option" variable is filled in with "5" string, go to next step
            search_item() # call "search_item()" function
            break # use "break" function to completely terminate the while loop(1)
        elif (admin_menu_option=="6"): # else if "admin_menu_option" variable is filled in with "6" string, go to next step
            view_all_order() # call "view_all_order()" function
            break # use "break" function to completely terminate the while loop(1)
        elif (admin_menu_option=="7"): # else if "admin_menu_option" variable is filled in with "7" string, go to next step
            search_order() # call "search_order()" function
            break # use "break" function to completely terminate the while loop(1)
        elif (admin_menu_option=="8"): # else if "admin_menu_option" variable is filled in with "8" string, go to next step
            admin_register() # call "admin_register()" function
            break # use "break" function to completely terminate the while loop(1)
        elif (admin_menu_option=="9"): # else if "admin_menu_option" variable is filled in with "9" string, go to next step
            menu() # call "menu()" function
            break # use "break" function to completely terminate the while loop(1)
        else: #  else if "admin_menu_option" variable is not filled in with "1" string or "2" string or "3" string or "4" string or "5" string or "6" string or "7" string or "8" string or "9" string, go to next step
            print("Invalid input!") # display "Invalid input!" string to remind admin to choose valid option and restart the while loop(1)

# admin menu option 1
def admin_view_item(): # create "admin_view_item()" function to enable admin to view all groceries sell at FRESHO
    print("\n─────────────────View Items─────────────────\n") # display "\n─────────────────View Items─────────────────\n" string as main topic of "admin_menu()" function
    drycount=0 # set "drycount" variable as "0" integer
    wetcount=0 # set "wetcount" variable as "0" integer
    stationerycount=0 # set "stationerycount" variable as "0" integer
    with open ("groceries.txt","r") as read_groceries_file: # use "with open ()" function to open "groceries.txt" for reading and then automatically close the file, make it as "read_groceries_file" variable 
        for line in read_groceries_file: # use for loop and hold the value as "line" variable from "read_groceries_file" variable during the iteration
            if "dry" in line: # if "dry" string in "line" variable, go to next step
                if drycount==0: # if "drycount" variable is equal to "0" integer, go to next step
                    print("DRY:") # display "DRY:" string as category topic
                    drycount+=1 # add "1" integer to the "drycount" variable and assign the result to "drycount" variable
                print(line.strip()) # use strip() to remove spaces at the beginning and at the end of "line" variable and then display it
    with open ("groceries.txt","r") as read_groceries_file: # use "with open ()" function to open "groceries.txt" for reading and then automatically close the file, make it as "read_groceries_file" variable 
        for line in read_groceries_file: # use for loop and hold the value as "line" variable from "read_groceries_file" variable during the iteration
            if "wet" in line: # if "wet" string in "line" variable, go to next step
                if wetcount==0: # if "wetcount" variable is equal to "0" integer, go to next step
                    print("\nWET:") # display "\nWET:" string as category topic
                    wetcount+=1 # add "1" integer to the "wetcount" variable and assign the result to "wetcount" variable
                print(line.strip()) # use strip() to remove spaces at the beginning and at the end of "line" variable and then display it
    with open ("groceries.txt","r") as read_groceries_file: # use "with open ()" function to open "groceries.txt" for reading and then automatically close the file, make it as "read_groceries_file" variable 
        for line in read_groceries_file: # use for loop and hold the value as "line" variable from "read_groceries_file" variable during the iteration
            if "stationery" in line: # if "stationery" string in "line" variable, go to next step
                if stationerycount==0: # if "stationerycount" variable is equal to "0" integer, go to next step
                    print("\nSTATIONERY:") # display "\nSTATIONERY:" string as category topic
                    stationerycount+=1 # add "1" integer to the "stationerycount" variable and assign the result to "stationerycount" variable
                print(line.strip()) # use strip() to remove spaces at the beginning and at the end of "line" variable and then display it
    while True: # create while loop(1) with "True" as the condition
        print("\nDo you want to do something?") # display "\nDo you want to do something?" string as question 
        print("(1) >>>>>>>>>> Upload items.") # display "(1) >>>>>>>>>> Upload items." string as upload items selection
        print("(2) >>>>>>>>>> Delete items.") # display "(2) >>>>>>>>>> Delete items." string as delete items selection
        print("(3) >>>>>>>>>> Edit items.") # display "(3) >>>>>>>>>> Edit items." string as edit items selection
        print("(4) >>>>>>>>>>Nothing to do.") # display "(4) >>>>>>>>>>Nothing to do." string as terminate selection
        continue_option=input("Enter your selection: ") # use “input()” function with "Enter your selection: " string to ask admin to input his selection and make it as "continue_option" variable
        if(continue_option=="1"): # if “continue_option" variable is filled in with "1" string, go to next step
            upload_item() # call "upload_item()" function
            break # use "break" function to completely terminate the while loop(1)
        elif(continue_option=="2"): # else if “continue_option" variable is filled in with "2" string, go to next step
            delete_item() # call "delete_item()" function
            break # use "break" function to completely terminate the while loop(1)
        elif(continue_option=="3"): # else if “continue_option" variable is filled in with "3" string, go to next step
            edit_item() # call "edit_item()" function
            break # use "break" function to completely terminate the while loop(1)
        elif(continue_option=="4"): # else if “continue_option" variable is filled in with "4" string, go to next step
            admin_menu() # call "admin_menu()" function
            break # use "break" function to completely terminate the while loop(1)
        else: # else if "continue_option" variable is not filled in with "1" string or "2" string or "3" string or "4" string, go to next step
            print("Please choose valid option!") # display "Please choose valid option!" string to remind admin to choose valid option and restart the while loop(1)
                
# admin menu option 2
def upload_item(): # create "upload_item()" function to enable admin to upload new items
    print("\n─────────────────Upload Items─────────────────\n") # display "\n─────────────────Upload Items─────────────────\n" string as main topic of "upload_item()" function
    while True: # create while loop(1) with "True" as the condition
        item_name=input("What you want to upload? : ") # use “input()” function with "What you want to upload? : " string to ask admin to input what admin want to upload and make it as "item_name" variable
        if item_name=="": # if "item_name" variable is equal to "" string, go to next step
            print("Please don't blank!") # display "Please don't blank!" string to remind not to be blank
            continue # use "continue" function to back to the beginning of the while loop(1)
        else: # else if "item_name" variable is not equal to "" string, go to next step
            break # use "break" function to completely terminate the while loop(1)
    while True: # create while loop(2) with "True" as the condition
        item_price=(input("What is its price? [MYR]: "))  # use “input()” function with "What is its price? [MYR] : " string to ask admin to input price of the item and make it as "item_price" variable
        if item_price=="": # if "item_price" variable is equal to "" string, go to next step
            print("Please don't blank!") # display "Please don't blank!" string to remind not to be blank
            continue # use "continue" function to back to the beginning of the while loop(2)
        else: # else if "item_price" variable is not equal to "" string, go to next step
            break # use "break" function to completely terminate the while loop(2)
    while True: # create while loop(3) with "True" as the condition
        item_category=input("What is its category? [wet ,dry, stationery]: ") # use “input()” function with "What is its category? [wet ,dry, stationery] : " string to ask admin to input category of the item and make it as "item_category" variable
        if (item_category=="wet") or (item_category=="dry") or (item_category=="stationery"): # if "item_category" variable is filled in with "wet" string or "dry" string or "stationery" string, go to next step
            break # use "break" function to completely terminate the while loop(3)
        else: # else if "item_category" variable is not filled in with "wet" string or "dry" string or "stationery" string, go to next step
            print("Please enter valid category!") # display "Please enter valid category!" string to remind admin to fill in valid category
    item_date=input("What is its expired date? [e.g. 2000/00/00 or -]: ") # use “input()” function with "What is its expired date? [e.g. 2000/00/00 or -]: " string to ask admin to input expired date of the item and make it as "item_date" variable
    with open("groceries.txt","a") as groceries_file:  # use "with open ()" function to open "groceries.txt" for appending and then automatically close the file, make it as "groceries_file" variable
        groceries_file.write("\nname: {} price: RM{} category: {} expired date: {}".format(item_name,item_price,item_category,item_date))
        # use “write()” function to write "item_name" variable, "item_price" variable, "item_category" variable , "item_date"  variable in "groceries.txt"
        # use "str.format()" function to let "item_name" variable, "item_price" variable, "item_category" variable , "item_date"  variable to be written following the format
    while True: # create while loop(4) with "True" as the condition
        print("\nSuccessfully uploaded! Is there anything else to upload?") # display "\nSuccessfully uploaded! Is there anything else to upload? " string as question 
        print("(1) >>>>>>>>>> Yes.") # display "(1) >>>>>>>>>> Yes." string as continue selection
        print("(2) >>>>>>>>>> No.") # display "(2) >>>>>>>>>> No." string as terminate selection
        continue_option=input("Enter your selection: ") # use “input()” function with "Enter your selection: " string to ask admin to input his selection and make it as "continue_option" variable
        if (continue_option=="1"): # if “continue_option" variable is filled in with "1" string, go to next step
            upload_item() # call "upload_item()" function
            break # use "break" function to completely terminate the while loop(4)
        elif (continue_option=="2"): # else if “continue_option" variable is filled in with "2" string, go to next step
            admin_menu() # call "admin_menu()" function
            break # use "break" function to completely terminate the while loop(4)
        else: # else if "continue_option" variable is not filled in with "1" string or "2" string, go to next step
            print("Please choose valid option!") # display "Please choose valid option!" string to remind admin to choose valid option and restart the while loop(4)

# admin menu option 3
def edit_item(): # create "edit_item()" function to enable admin to edit existing items
    print("\n─────────────────Edit Items─────────────────\n") # display "\n─────────────────Edit Items─────────────────\n" string as main topic of "edit_item()" function
    while True: # create while loop(1) with "True" as the condition
        item_edit=input("What you want to edit? : ") # use “input()” function with "What you want to edit? : " string to ask admin to input what admin want to edit and make it as "item_edit" variable
        if item_edit=="":  # if "item_edit" variable is equal to "" string, go to next step
            print("Please don't blank!") # display "Please don't blank!" string to remind not to be blank
            continue # use "continue" function to back to the beginning of the while loop(1)
        else: # else if "item_edit" variable is not equal to "" string, go to next step
            with open ("groceries.txt","r") as read_groceries_file:  # use “with open ()” function to open "groceries.txt" for reading and then automatically close the file, make it as "read_groceries_file" variable
                read=read_groceries_file.readlines() # use “readlines()” function to read contents of "read_groceries_file" variable line by line, put the read contents into a list and then make it as “read” variable
            with open ("groceries.txt","w") as write_groceries_file: # use "with open ()" function to open "groceries.txt" for writing and then automatically close the file, make it as "write_groceries_file" variable
                for line in read: # use for loop and hold the value as "line" variable from "read" variable during the iteration
                    if item_edit not in line: # if "item_edit" variable not in "line" variable, go to next step
                        write_groceries_file.write(line) # use “write()” function to write "line" variable in "groceries.txt"
                    else: # else if "item_edit" variable in "line" variable, go to next step
                        while True: # create while loop(2) with "True" as the condition
                            item_price=input("What is its price? [MYR]: ") # use “input()” function with "What is its price? [MYR] : " string to ask admin to input price of the edit item and make it as "item_price" variable
                            if item_price=="": # if "item_price" variable is equal to "" string, go to next step
                                print("Please don't blank!") # display "Please don't blank!" string to remind not to be blank
                                continue # use "continue" function to back to the beginning of the while loop(2)
                            else: # else if "item_price" variable is not equal to "" string, go to next step
                                break # use "break" function to completely terminate the while loop(2)
                        while True: # create while loop(3) with "True" as the condition
                            item_category=input("What is its category? [wet ,dry, stationery]: ") # use “input()” function with "What is its category? [wet ,dry, stationery] : " string to ask admin to input category of the item and make it as "item_category" variable
                            if (item_category=="wet")or(item_category=="dry")or(item_category=="stationery"): # if "item_category" variable is filled in with "wet" string or "dry" string or "stationery" string, go to next step
                                break # use "break" function to completely terminate the while loop(3)
                            else: # else if "item_category" variable is not filled in with "wet" string or "dry" string or "stationery" string, go to next step
                                print("Please enter valid category!") # display "Please enter valid category!" string to remind admin to fill in valid category
                        item_date=input("What is its expired date? [e.g. 2000/00/00 or -]: ") # use “input()” function with "What is its expired date? [e.g. 2000/00/00 or -]: " string to ask admin to input expired date of the item and make it as "item_date" variable
                        with open ("groceries.txt","a") as groceries_file: # use "with open ()" function to open "groceries.txt" for appending and then automatically close the file, make it as "groceries_file" variable
                            write_groceries_file.write("name: {} price: RM{} category: {} expired date: {}".format(item_edit,item_price,item_category,item_date))
                            # use “write()” function to write "item_edit" variable, "item_price" variable, "item_category" variable and "item_date"  variable in "groceries.txt"
                            # use "str.format()" function to let "item_edit" variable, "item_price" variable, "item_category" variable and "item_date"  variable to be written following the format
        break # use "break" function to completely terminate the while loop(1)
    while True: # create while loop(4) with "True" as the condition
        print("\nSuccessfully edited! Is there anything else to edit?") # display "\nSuccessfully edited! Is there anything else to edit? " string as question 
        print("(1) >>>>>>>>>> Yes.") # display "(1) >>>>>>>>>> Yes." string as continue selection
        print("(2) >>>>>>>>>> No.") # display "(2) >>>>>>>>>> No." string as terminate selection
        continue_option=input("Enter your selection: ") # use “input()” function with "Enter your selection: " string to ask admin to input his selection and make it as "continue_option" variable
        if (continue_option=="1"): # if “continue_option" variable is filled in with "1" string, go to next step
            edit_item() # call "edit_item()" function
            break # use "break" function to completely terminate the while loop(4)
        elif (continue_option=="2"): # else if “continue_option" variable is filled in with "2" string, go to next step
            admin_menu() # call "admin_menu()" function
            break # use "break" function to completely terminate the while loop(4)
        else: # else if "continue_option" variable is not filled in with "1" string or "2" string, go to next step
            print("Please choose valid option!") # display "Please choose valid option!" string to remind admin to choose valid option and restart the while loop(4)
        
# admin menu option 4
def delete_item(): # create "delete_item()" function to enable admin to delete existing items
    print("\n─────────────────Delete Items─────────────────\n") # display "\n─────────────────Delete Items─────────────────\n" string as main topic of "delete_item()" function
    while True: # create while loop(1) with "True" as the condition
        item_delete=input("What you want to delete? [Please enter its name]: ") # use “input()” function with "What you want to delete? [Please enter its name] : " string to ask admin to input what admin want to delete and make it as "item_delete" variable
        if item_delete=="": # if "item_delete" variable is not equal to "" string, go to next step
            print("Please don't blank!") # display "Please don't blank!" string to remind not to be blank
            continue # use "continue" function to back to the beginning of the while loop(1)
        else: # if "item_delete" variable is not equal to "" string, go to next step
            with open("groceries.txt","r") as read_groceries_file: # use "with open ()" function to open "groceries.txt" for reading and then automatically close the file, make it as "read_groceries_file" variable
                read=read_groceries_file.readlines() # use “readlines()” function to read contents of "read_groceries_file" variable line by line, put the read contents into a list and then make it as “read” variable
            with open("groceries.txt","w") as write_groceries_file: # use "with open ()" function to open "groceries.txt" for writing and then automatically close the file, make it as "write_groceries_file" variable
                for line in read: # use for loop and hold the value as "line" variable from "read" variable during the iteration
                    if "name: "+item_delete not in line: # if "name: " string + "item_delete" variable not in "line" variable, go to next step
                        write_groceries_file.write(line) # use “write()” function to write "line" variable in "groceries.txt"
            break # use "break" function to completely terminate the while loop(1)
    while True: # create while loop(2) with "True" as the condition
        print("\nSuccessfully deleted! Is there anything else to delete?") # display "\nSuccessfully deleted! Is there anything else to delete? " string as question 
        print("(1) >>>>>>>>>> Yes.") # display "(1) >>>>>>>>>> Yes." string as continue selection
        print("(2) >>>>>>>>>> No.") # display "(2) >>>>>>>>>> No." string as terminate selection
        continue_option=input("Enter your selection: ") # use “input()” function with "Enter your selection: " string to ask admin to input his selection and make it as "continue_option" variable
        if (continue_option=="1"): # if “continue_option" variable is filled in with "1" string, go to next step
            delete_item() # call "delete_item()" function
            break # use "break" function to completely terminate the while loop(2)
        elif (continue_option=="2"): # else if “continue_option" variable is filled in with "2" string, go to next step
            admin_menu() # call "admin_menu()" function
            break # use "break" function to completely terminate the while loop(2)
        else: # else if "continue_option" variable is not filled in with "1" string or "2" string, go to next step
            print("Please choose valid option!") # display "Please choose valid option!" string to remind admin to choose valid option and restart the while loop(2)

# admin menu option 5
def search_item(): # create "search_item()" function to enable admin to search specific item sell at FRESHO
    print("\n─────────────────Search Item─────────────────\n") # display "\n─────────────────Search Item─────────────────\n" string as main topic of "search_item()" function
    while True: # create while loop(1) with "True" as the condition
        item_search=input("What you want to search? [Please enter its name or category]: ")
        # use “input()” function with "What you want to search? [Please enter its name or category] : " string to ask admin to input what admin want to search and make it as "item_search" variable
        if item_search=="": # if "item_search" variable is equal to "" string, go to next step
            print("Please don't blank!") # display "Please don't blank!" string to remind not to be blank
            continue # use "continue" function to back to the beginning of the while loop(1)
        else: # if "item_search" variable is not equal to "" string, go to next step
            break # use "break" function to completely terminate the while loop(1)
    print("\nResult:") # display "\nResult:" string
    with open("groceries.txt","r") as read_groceries_file: # use "with open ()" function to open "groceries.txt" for reading and then automatically close the file, make it as "read_groceries_file" variable
        read=read_groceries_file.readlines() # use “readlines()” function to read contents of "read_groceries_file" variable line by line, put the read contents into a list and then make it as “read” variable
        for line in read: # use for loop and hold the value as "line" variable from "read" variable during the iteration
            if "name: "+item_search in line or "category: "+item_search in line : # if "name: " string + "item_search" variable or "category: " string + "item_search" variable not in "line" variable, go to next step
                print(line.strip()) # use strip() to remove spaces at the beginning and at the end of "line" variable and then display it
    while True: # create while loop(2) with "True" as the condition
        print("\nIs there anything else to search?") # display "\nIs there anything else to search? " string as question
        print("(1) >>>>>>>>>> Yes.") # display "(1) >>>>>>>>>> Yes." string as continue selection
        print("(2) >>>>>>>>>> No.") # display "(2) >>>>>>>>>> No." string as terminate selection
        continue_option=input("Enter your selection: ") # use “input()” function with "Enter your selection: " string to ask admin to input his selection and make it as "continue_option" variable
        if (continue_option=="1"): # if “continue_option" variable is filled in with "1" string, go to next step
            search_item() # call "search_item()" function
            break # use "break" function to completely terminate the while loop(2)
        elif (continue_option=="2"): # else if “continue_option" variable is filled in with "2" string, go to next step
            admin_menu() # call "admin_menu()" function
            break # use "break" function to completely terminate the while loop(2)
        else: # else if "continue_option" variable is not filled in with "1" string or "2" string, go to next step
            print("Please choose valid option!") # display "Please choose valid option!" string to remind admin to choose valid option and restart the while loop(2)

 # admin menu option 6
def view_all_order(): # create "view_all_order()" function to enable admin to sell all order placed by customers
    print("\n─────────────────View All Orders─────────────────\n") # display "\n─────────────────View All Orders─────────────────\n" string as main topic of "search_order()" function
    with open ("order.txt","r") as read_order_file: # use "with open ()" function to open "order.txt" for reading and then automatically close the file, make it as "read_order_file" variable
        read=read_order_file.readlines() # use “readlines()” function to read contents of "read_order_file" variable line by line, put the read contents into a list and then make it as “read” variable
        for line in read: # use for loop and hold the value as "line" variable from "read" variable during the iteration
            print(line.strip()) # use strip() to remove spaces at the beginning and at the end of "line" variable and then display it
        admin_menu() # call "admin_menu()" function

# admin menu option 7
def search_order(): # create "search_order()" function to enable admin to search specific customer's order
    print("\n─────────────────Search Order─────────────────\n") # display "\n─────────────────Search Order─────────────────\n" string as main topic of "search_order()" function
    while True: # create while loop(1) with "True" as the condition
        username_input=input("Please enter customer's username you want to search: ")
        # use “input()” function with "Please enter customer's username you want to search: " string to ask admin to input what admin want to search and make it as "username_input" variable
        if username_input=="": # if "username_input" variable is equal to "" string, go to next step
            print("Please don't blank!") # display "Please don't blank!" string to remind not to be blank and restart the while loop(1)
        else: # else # if "username_input" variable is not equal to "" string, go to next step
            break # use "break" function to completely terminate the while loop(1)
    print("\nResult:") # display "\nResult:" string
    with open ("order.txt","r") as read_order_file: # use "with open ()" function to open "order.txt" for reading and then automatically close the file, make it as "read_order_file" variable
        read=read_order_file.readlines() # use “readlines()” function to read contents of "read_order_file" variable line by line, put the read contents into a list and then make it as “read” variable
    for line in read: # use for loop and hold the value as "line" variable from "read" variable during the iteration
        if username_input+":" in line: # if "username_input" variable + ":" string in "line" variable, go to next step
            print(line.strip()) # use strip() to remove spaces at the beginning and at the end of "line" variable and then display it
    while True: # create while loop(2) with "True" as the condition
        print("\nIs there anything else to search?") # display "\nIs there anything else to search? " string as question
        print("(1) >>>>>>>>>> Yes.") # display "(1) >>>>>>>>>> Yes." string as continue selection
        print("(2) >>>>>>>>>> No.") # display "(2) >>>>>>>>>> No." string as terminate selection
        continue_option=input("Enter your selection: ") # use “input()” function with "Enter your selection: " string to ask admin to input his selection and make it as "continue_option" variable
        if (continue_option=="1"): # if “continue_option" variable is filled in with "1" string, go to next step
            search_order() # call "search_order()" function
            break # use "break" function to completely terminate the while loop(2)
        elif (continue_option=="2"): # else if “continue_option" variable is filled in with "2" string, go to next step
            admin_menu() # call "admin_menu()" function
            break # use "break" function to completely terminate the while loop(2)
        else: # else if "continue_option" variable is not filled in with "1" string or "2" string, go to next step
            print("Please choose valid option!") # display "Please choose valid option!" string to remind admin to choose valid option and restart the while loop(2)
            
 #admin menu option 8 
def admin_register(): # create "admin_register()" function to enable admin to create a new admin account for new colleague
    print("\n─────────────────Create New Admin─────────────────\n") # display "\n─────────────────Create New Admin─────────────────\n" string as main topic of "admin_register()" function
    while True: # create while loop(1) with "True" as the condition
        admin_username=input("Please create admin username: ") # use “input()” function with "Please create admin username: " string to ask admin to create new admin username and make it as "admin_username" variable
        if admin_username=="": # if "admin_username" variable is equal to "" string, go to next step
            print("Please don't blank!") # display "Please don't blank!" string to remind not to be blank
            continue # use "continue" function to back to the beginning of the while loop(1)
        else: # else if "item_name" variable is not equal to "" string, go to next step
            break # use "break" function to completely terminate the while loop(1)
    while True: # create while loop(2) with "True" as the condition
        admin_password=input("Please create admin password: ") # use “input()” function with "Please create admin password: " string to ask admin to create new admin password and make it as "admin_password" variable
        if admin_password=="": # if "admin_password" variable is equal to "" string, go to next step
            print("Please don't blank!") # display "Please don't blank!" string to remind not to be blank
            continue # use "continue" function to back to the beginning of the while loop(2)
        else:# else if "admin_password" variable is not equal to "" string, go to next step
            break # use "break" function to completely terminate the while loop(2)   
    while True: # create while loop(3) with "True" as the condition
        confirm_admin_password=input("Please confirm admin password: ") # use “input()” function with "Please confirm admin password: " string to ask admin to confirm created admin password and make it as "confirm_admin_password" variable
        if admin_password==confirm_admin_password: # if "admin_password" variable is equal to "confirm_admin_password" variable, go to next step
            with open ("admin.txt","a") as admin_file:  # use "with open ()" function to open "admin.txt" for appending and then automatically close the file, make it as "admin_file" variable
                admin_file.write("\nusername: {}\\ password: {}\\".format(admin_username,admin_password))
                # use “write()” function to write "admin_username" variable and  "admin_password" variable in "admin.txt"
                # use "str.format()" function to let  "admin_username" variable and "admin_password" variable to be written following the format
                break  # use "break" function to completely terminate the while loop(3)
        else: # else if "admin_password" variable is not equal to "confirm_admin_password" variable, go to next step
            print("Password doesn't match, please input again.") # display "Password doesn't match, please input again." string as reminder that password don't match, admin need to input again, and restart the loop(3)
    while True:  # create while loop(4) with "True" as the condition
        print("\nSuccessfully created! Do you want to continue? ") # display "\nSuccessfully created! Do you want to continue? " string as question
        print("(1) >>>>>>>>>> Yes.") # display "(1) >>>>>>>>>> Yes." string as continue selection
        print("(2) >>>>>>>>>> No.") # display "(2) >>>>>>>>>> No." string as terminate selection
        continue_option=input("Enter your selection: ") # use “input()” function with "Enter your selection: " string to ask admin to input his selection and make it as "continue_option" variable
        if (continue_option=="1"): # if “continue_option" variable is filled in with "1" string, go to next step
            admin_register() # call "admin_register()" function
            break # use "break" function to completely terminate the while loop(4)
        elif (continue_option=="2"): # else if “continue_option" variable is filled in with "2" string, go to next step
            admin_menu() # call "admin_menu()" function
            break # use "break" function to completely terminate the while loop(4)
        else: # else if "continue_option" variable is not filled in with "1" string or "2" string, go to next step
            print("Please choose valid option!") # display "Please choose valid option!" string to remind admin to choose valid option and restart the while loop(4)

# customer part

# question: customer have account?
def customer(): # create "customer()" function to ask customer has account or not
    while True: # create while loop(1) with "True" as the condition
        print("\nDo you have account or not?") # display "\nDo you have account or not?" string as question
        print("(1) >>>>>>>>>> Yes, log in my account.") # display "(1) >>>>>>>>>> Yes, log in my account." string as customer login selection
        print("(2) >>>>>>>>>> No, I am a new customer.") # display "(2) >>>>>>>>>> No, I am a new customer." string as new customer selection
        customer_option=input("Enter your selection: ") # use “input()” function with "Enter your selection: " string to ask customer to input his selection and make it as "customer_option" variable
        if (customer_option=="1"): # if “customer_option" variable is filled in with "1" string, go to next step
            customer_login() # call "customer_login()" function
            break # use "break" function to completely terminate the while loop(1)
        elif (customer_option=="2"): # else if “customer_option" variable is filled in with "2" string, go to next step
             new_customer() # call "new_customer()" function
             break # use "break" function to completely terminate the while loop(1)
        else: # else if "continue_option" variable is not filled in with "1" string or "2" string, go to next step
            print("Please choose valid option!") # display "Please choose valid option!" string to remind customer to choose valid option and restart the while loop(1)

def new_customer(): # create "new_customer()" function to ask customer what he want to do
    while True: # create while loop(1) with "True" as the condition
        print("\n─────────────────New Customer─────────────────\n") # display "\n─────────────────New Customer─────────────────\n" string as main topic of "new_customer()" function
        print("What do you want to do?") # display "\nDo you have account or not?" string as question
        print("(1) >>>>>>>>>> View groceries.") # display "(1) >>>>>>>>>> View groceries." string as view groceries selection
        print("(2) >>>>>>>>>> Create a new account.") # display "(2) >>>>>>>>>> Create a new account." string as customer register selection
        newcs_option=input("Enter your selection: ") # use “input()” function with "Enter your selection: " string to ask customer to input his selection and make it as "newcs_option" variable
        if (newcs_option=="1"): # if “newcs_option" variable is filled in with "1" string, go to next step
            drycount=0 # set "drycount" variable as "0" integer
            wetcount=0 # set "wetcount" variable as "0" integer
            stationerycount=0 # set "stationerycount" variable as "0" integer
            with open ("groceries.txt","r") as read_groceries_file: # use "with open ()" function to open "groceries.txt" for reading and then automatically close the file, make it as "read_groceries_file"
                for line in read_groceries_file: # use for loop and hold the value as "line" variable from "read_groceries_file" variable during the iteration
                    if "dry" in line: # if "dry" string in "line" variable, go to next step
                        if drycount==0: # if "drycount" variable is equal to "0" integer, go to next step
                            print("\nDRY:") # display "\nDRY:" string as category topic
                            drycount+=1 # add "1" integer to the "drycount" variable and assign the result to "drycount" variable
                        print(line.strip()) # use strip() to remove spaces at the beginning and at the end of "line" variable and then display it
            with open ("groceries.txt","r") as read_groceries_file: # use "with open ()" function to open "groceries.txt" for reading and then automatically close the file, make it as "read_groceries_file"
                for line in read_groceries_file:  # use for loop and hold the value as "line" variable from "read_groceries_file" variable during the iteration
                    if "wet" in line: # if "wet" string in "line" variable, go to next step
                        if wetcount==0: # if "wetcount" variable is equal to "0" integer, go to next step
                            print("\nWET:") # display "\nWET:" string as category topic
                            wetcount+=1 # add "1" integer to the "wetcount" variable and assign the result to "wetcount" variable
                        print(line.strip()) # use strip() to remove spaces at the beginning and at the end of "line" variable and then display it
            with open ("groceries.txt","r") as read_groceries_file: # use "with open ()" function to open "groceries.txt" for reading and then automatically close the file, make it as "read_groceries_file"
                for line in read_groceries_file:  # use for loop and hold the value as "line" variable from "read_groceries_file" variable during the iteration
                    if "stationery" in line: # if "stationery" string in "line" variable, go to next step
                        if stationerycount==0: # if "stationerycount" variable is equal to "0" integer, go to next step
                            print("\nSTATIONERY:") # display "\nSTATIONERY:" string as category topic
                            stationerycount+=1 # add "1" integer to the "stationerycount" variable and assign the result to "stationerycount" variable
                        print(line.strip()) # use strip() to remove spaces at the beginning and at the end of "line" variable and then display it
            break # use "break" function to completely terminate the while loop(1)
        elif (newcs_option=="2"): # else if “newcs_option" variable is filled in with "2" string, go to next step
            customer_register() # call "customer_register" function
            break # use "break" function to completely terminate the while loop(1)
        else: # else if "newcs_option" variable is not filled in with "1" string or "2" string, go to next step
            print("Please choose valid option!") # display "Please choose valid option!" string to remind customer to choose valid option and restart the while loop(1)
    while True: # create while loop(2) with "True" as the condition
        print("\nIf you want to order, you must have an account.") # display "\nIf you want to order, you must have an account." string as reminder that customer need to create new account
        print("(1) >>>>>>>>>> I want to create a new account.") # display "(1) >>>>>>>>>> I want to create a new account." string as customer register selection
        print("(2) >>>>>>>>>> Back to main menu.") # display "(2) >>>>>>>>>> Back to main menu." string as back to main menu selection
        register_option=input("Enter your selection: ") # use “input()” function with "Enter your selection: " string to ask customer to input his selection and make it as "register_option" variable
        if (register_option=="1"): # if “register_option" variable is filled in with "1" string, go to next step
            customer_register() # call "customer_register" function
            break # use "break" function to completely terminate the while loop(2)
        elif (register_option=="2"): # else if “register_option" variable is filled in with "2" string, go to next step
            menu() # call "menu" function
            break # use "break" function to completely terminate the while loop(2)
        else: # else if "register_option" variable is not filled in with "1" string or "2" string, go to next step
            print("Please choose valid option!" ) # display "Please choose valid option!" string to remind customer to choose valid option and restart the while loop(2)
        
# customer register
def customer_register(): # create "customer_register()" function for the registration of new customer
    print("\n─────────────────Customer Register─────────────────\n") # display "\n─────────────────Customer Register─────────────────\n" string as main topic of "customer_register()" function
    while True: # create while loop(1) with "True" as the condition
        customer_name=input("Please enter your name: ") # use “input()” function with "Please enter your name: " string to ask customer to input his name and make it as "customer_name" variable
        if customer_name=="": # if "customer_name" variable is equal to "" string, go to next step
            print("Please don't blank!") # display "Please don't blank!" string to remind not to be blank
            continue # use "continue" function to back to the beginning of the while loop(1)
        else: # else if "customer_name" variable is not equal to "" string, go to next step
            break # use "break" function to completely terminate the while loop(1)
    while True: # create while loop(2) with "True" as the condition
        customer_address=input("Please enter your home address: ") # use “input()” function with "Please enter your address: " string to ask customer to input his home address and make it as "customer_address" variable
        if customer_address=="": # if "customer_address" variable is equal to "" string, go to next step
            print("Please don't blank!") # display "Please don't blank!" string to remind not to be blank
            continue # use "continue" function to back to the beginning of the while loop(2)
        else: # else if "customer_address" variable is not equal to "" string, go to next step
            break # use "break" function to completely terminate the while loop(2)
    while True: # create while loop(3) with "True" as the condition
        customer_email=input("Please enter your email ID: ") # use “input()” function with "Please enter your email ID: " string to ask customer to input his email address and make it as "customer_email" variable
        if "@" not in customer_email or "." not in customer_email: # if "@" string or "." string not in "customer_email" variable, go to next step
            print("Please enter correct format.") # display "Please enter correct format." string to remind customer to input email address by the correct format
            continue # use "continue" function to back to the beginning of the while loop(3)
        else: # else if "@" string or "." string in "customer_email" variable, go to next step
            break # use "break" function to completely terminate the while loop(3)
    while True: # create while loop(4) with "True" as the condition
        customer_phone=input("Please enter your contact number: ") # use “input()” function with "Please enter your contact number: " string to ask customer to input his phone number and make it as "customer_phone" variable
        if customer_phone!="": # if "customer_phone" variable is not equal to "" string, go to next step
            break # use "break" function to completely terminate the while loop(4)
        else: # else if "customer_phone" variable is equal to "" string, go to next step
            print("Please don't blank!") # display "Please don't blank!" string to remind not to be blank and restart the while loop(4)
    while True: # create while loop(5) with "True" as the condition
        customer_gender=input("Please enter your gender: ") # use “input()” function with "Please enter your gender: " string to ask customer to input his gender and make it as "customer_gender" variable
        if (customer_gender=="male") or (customer_gender=="female"): # if "customer_gender" variable is filled in with "male" string or "female" string, go to next step
            break # use "break" function to completely terminate the while loop(5)
        else: # else if "customer_gender" variable is not filled in with "male" string or "female" string, go to next step
            print("Please enter <male> or< female>. ") # display "Please enter male or female. " string to remind customer to fill in "male" string or "female" string and restart the while loop(5)
    while True: # create while loop(6) with "True" as the condition
        customer_birthday=input("Please enter your date of birth [e.g. 2000/00/00]: ") # use “input()” function with "Please enter your date of birth [e.g. 2000/00/00] : " string to ask customer to input his birthday and make it as "customer_birthday" variable
        if customer_birthday=="": # if "customer_birthday" variable is equal to "" string, go to next step
            print("Please don't blank!") # display "Please don't blank!" string to remind not to be blank
            continue # use "continue" function to back to the beginning of the while loop(6)
        else: # else if "customer_birthday" variable is not equal to "" string, go to next stepp
            break # use "break" function to completely terminate the while loop(6)
    while True: # create while loop(7) with "True" as the condition
        customer_username=input("Please create your username: ") # use “input()” function with "Please create your username: " string to ask customer to create his username and make it as "customer_username" variable
        if customer_username=="": # if "customer_username" variable is equal to "" string, go to next step
            print("Please don't blank!") # display "Please don't blank!" string to remind not to be blank
            continue # use "continue" function to back to the beginning of the while loop(7)
        else: # else if "customer_username" variable is not equal to "" string, go to next step
            break # use "break" function to completely terminate the while loop(7)
    while True: # create while loop(8) with "True" as the condition
        customer_password=input("Please create your password: ") # use “input()” function with "Please create your password: " string to ask customer to create his password and make it as "customer_password" variable
        if customer_password=="": # if "customer_password" variable is equal to "" string, go to next step
            print("Please don't blank!") # display "Please don't blank!" string to remind not to be blank
            continue # use "continue" function to back to the beginning of the while loop(8)
        else: # else if "customer_password" variable is not equal to "" string, go to next step
            break# use "break" function to completely terminate the while loop(8)
    while True: # create while loop(9) with "True" as the condition
        confirm_customer_password=input("Please confirm your password: ") # use “input()” function with "Please confirm your password: " string to ask customer to confirm created password and make it as "confirm_customer_password" variable
        if customer_password==confirm_customer_password: # if "admin_password" variable is equal to "confirm_admin_password" variable, go to next step
            with open("customer.txt","a") as customer_file: # use "with open ()" function to open "customer.txt" for appending and then automatically close the file, make it as "customer_file" variable
                customer_file.write("\nname: {}\\ address: {}\\ email: {}\\ phone: +60{}\\ gender: {}\\ birthday: {}\\ username: {}\\ password: {}\\".format(customer_name,customer_address,customer_email,customer_phone,customer_gender,customer_birthday,customer_username,customer_password))
            # use “write()” function to write "customer_name" variable, "customer_address" variable, "customer_email" variable,↙
            # "customer_phone" variable, "customer_gender" variable, "customer_birthday" variable, "customer_username" variable and "customer_password" variable in "customer.txt"
            # use "str.format()" function to let  "customer_name" variable, "customer_address" variable, "customer_email" variable,↙
            # "customer_phone" variable, "customer_gender" variable, "customer_birthday" variable, "customer_username" variable and "customer_password" variable to be written following the format
            print("\nSuccessfully created! Please log in again.") # display "\nSuccessfully created! Please log in again." as reminder that create success
            customer_login() # call "customer_login" function
            break # use "break" function to completely terminate the while loop(9)
        else: # else if "admin_password" variable is not equal to "confirm_customer_password" variable, go to next step
            print("Password doesn't match, please input again.") # display "Password doesn't match, please input again." string as reminder that password don't match, customer need to input again, and restart the while loop(9)


# customer login            
def customer_login(): # create "customer_login()" function to enable customer to login his account
    print("\n─────────────────Customer Login─────────────────\n") # display "\n─────────────────Customer Login─────────────────\n" string as main topic of "customer_login()" function
    customer_username=input("Please enter your username: ") # use “input()” function with "Please enter your username: " string to ask customer to input his username and make it as "customer_username" variable
    with open ("customer.txt","r") as read_customer_file: # use "with open ()" function to open "customer.txt" for reading and then automatically close the file, make it as "read_customer_file" variable
        read=read_customer_file.readlines() # use “readlines()” function to read contents of "read_customer_file" variable line by line, put the read contents into a list and then make it as “read” variable
        for line in read: # use for loop and hold the value as "line" variable from "read" variable during the iteration
            if ("username: "+customer_username+"\\") in line: # if "username: " string + "customer_username" variable + "\\" string in "line" variable, go to next step
                customer_password=input("Please enter your password: ") # use “input()” function with "Please enter your password: " string to ask customer to input his password and make it as "customer_password" variable
                if ("password: "+customer_password+"\\") in line: # if "password: " string + "customer_password" variable + "\\" string in "line" variable, go to next step
                    print("Successfully log in! Welcome back, "+customer_username+".") # display "Successfully log in! Welcome back, " string + "customer_username" variable + "." string as reminder that login success
                    customer_menu() # call "customer_menu()" function
    while True: # create while loop(1) with "True" as the condition
        print("\nAccount doesn't exist or wrong password!") # display "\nAccount doesn't exist or wrong password!" string as reminder that cannot login 
        print("(1) >>>>>>>>>> Log in again.") # display "(1) >>>>>>>>>> Log in again." string as continue selection
        print("(2) >>>>>>>>>> Create new one.") # display "(2) >>>>>>>>>> Create new one." string as register selection
        print("(3) >>>>>>>>>> Back to main menu.") # display "(3) >>>>>>>>>> Back to main menu." string as terminate selection
        register_option=input("Enter your selection: ") # use “input()” function with "Enter your selection: " string to ask customer to input his selection and make it as "register_option" variable
        if  (register_option=="1"): # if "register_option" variable is filled in with "1" string, go to next step
            customer_login() # call "customer_login()" function
            break # use "break" function to completely terminate the while loop(1)
        elif (register_option=="2"): # else if "register_option" variable is filled in with "2" string, go to next step
            customer_register() # call "customer_register()" function
            break # use "break" function to completely terminate the while loop(1)
        elif (register_option=="3"): # else if "register_option" variable is filled in with "3" string, go to next step
            menu() # call "customer_login" function
            break # use "break" function to completely terminate the while loop(1)
        else: # else if "register_option" variable is not filled in with "1" string or "2" string or "3" string, go to next step
            print("Please choose valid option!") # display "Please choose valid option!" string to remind customer to choose valid option and restart the while loop(1)

# customer menu
def customer_menu(): # create "customer_menu()" function to enable customer to choose what he wants to do
    while True: # create while loop(1) with "True" as the condition
        print("\n─────────────────Customer─────────────────\n") # display "\n─────────────────Customer─────────────────\n" string as main topic of "customer_menu()" function
        print("(1) >>>>>>>>>> View groceries.") # display "(1) >>>>>>>>>> View all items." string as view all items selection
        print("(2) >>>>>>>>>> Place order.") # display "(2) >>>>>>>>>> Place order." string as order selection
        print("(3) >>>>>>>>>> View own order history.") # display "(3) >>>>>>>>>> View own order history." string as view own order history selection
        print("(4) >>>>>>>>>> View own profile.") # display "(4) >>>>>>>>>> View own profile." string as view own profile selection
        print("(5) >>>>>>>>>> Log out.") # display "(5) >>>>>>>>>> Log out.\n" string as log out customer account selection
        customer_menu_option=input("Please choose your option: ")  # use “input()” function with "Please choose your option: " string to ask customer to input his selection and make it as "customer_menu_option" variable
        if (customer_menu_option=="1"): # if ”customer_menu_option" variable is filled in with "1" string, go to next step
            customer_view_groceries() # call "customer_view_groceries()" function
            break # use "break" function to completely terminate the while loop(1)
        elif (customer_menu_option=="2"): # if ”customer_menu_option" variable is filled in with "2" string, go to next step
            order() # call "order()" function
            break # use "break" function to completely terminate the while loop(1)
        elif (customer_menu_option=="3"): # if ”customer_menu_option" variable is filled in with "3" string, go to next step
            view_own_order() # call "view_own_order()" function
            break # use "break" function to completely terminate the while loop(1)
        elif (customer_menu_option=="4"): # if ”customer_menu_option" variable is filled in with "4" string, go to next step
            view_personal_info() # call " view_personal_info()" function
            break # use "break" function to completely terminate the while loop(1)
        elif (customer_menu_option=="5"): # if ”customer_menu_option" variable is filled in with "5" string, go to next step
            print("Thank you for coming.") # display "Thank you for coming." as reminder that log out success
            menu() # call "menu()" function
            break # use "break" function to completely terminate the while loop(1)
        else: #  else if "admin_menu_option" variable is not filled in with "1" string or "2" string or "3" string or "4" string or "5" string, go to next step
            print("Invalid input!") # display "Invalid input!" string to remind customer to choose valid option and restart the while loop(1)

# customer menu option 1
def customer_view_groceries(): # create "customer_view_groceries()" function to enable customer to view all groceries sell at FRESHO
    print("\n─────────────────View Groceries─────────────────\n") # display "\n─────────────────View Groceries─────────────────\n" string as main topic of "customer_view_groceries()" function
    drycount=0 # set "drycount" variable as "0" integer
    wetcount=0 # set "wetcount" variable as "0" integer
    stationerycount=0 # set "stationerycount" variable as "0" integer
    with open ("groceries.txt","r") as read_groceries_file: # use "with open ()" function to open "groceries.txt" for reading and then automatically close the file, make it as "read_groceries_file"
        for line in read_groceries_file: # use for loop and hold the value as "line" variable from "read_groceries_file" variable during the iteration
            if "dry" in line: # if "dry" string in "line" variable, go to next step
                if drycount==0: # if "drycount" variable is equal to "0" integer, go to next step
                    print("DRY:") # display "DRY:" string as category topic
                    drycount+=1 # add "1" integer to the "drycount" variable and assign the result to "drycount" variable
                print(line.strip()) # use strip() to remove spaces at the beginning and at the end of "line" variable and then display it
    with open ("groceries.txt","r") as read_groceries_file: # use "with open ()" function to open "groceries.txt" for reading and then automatically close the file, make it as "read_groceries_file"
        for line in read_groceries_file:  # use for loop and hold the value as "line" variable from "read_groceries_file" variable during the iteration
            if "wet" in line: # if "wet" string in "line" variable, go to next step
                if wetcount==0: # if "wetcount" variable is equal to "0" integer, go to next step
                    print("\nWET:") # display "\nWET:" string as category topic
                    wetcount+=1 # add "1" integer to the "wetcount" variable and assign the result to "wetcount" variable
                print(line.strip()) # use strip() to remove spaces at the beginning and at the end of "line" variable and then display it
    with open ("groceries.txt","r") as read_groceries_file: # use "with open ()" function to open "groceries.txt" for reading and then automatically close the file, make it as "read_groceries_file"
        for line in read_groceries_file:  # use for loop and hold the value as "line" variable from "read_groceries_file" variable during the iteration
            if "stationery" in line: # if "stationery" string in "line" variable, go to next step
                if stationerycount==0: # if "stationerycount" variable is equal to "0" integer, go to next step
                    print("\nSTATIONERY:") # display "\nSTATIONERY:" string as category topic
                    stationerycount+=1 # add "1" integer to the "stationerycount" variable and assign the result to "stationerycount" variable
                print(line.strip()) # use strip() to remove spaces at the beginning and at the end of "line" variable and then display it
    while True: # create while loop(1) with "True" as the condition
        print("\nDo you want to place an order?") # display "\nDo you want to place an order?" string as question
        print("(1) >>>>>>>>>> Yes.")  # display "(1) >>>>>>>>>> Yes." string as order selection
        print("(2) >>>>>>>>>> No.") # display "(2) >>>>>>>>>> No." string as terminate selection
        continue_option=input("Enter your selection: ") # use “input()” function with "Enter your selection: " string to ask customer to input his selection and make it as "continue_option" variable
        if(continue_option=="1"): # if “continue_option" variable is filled in with "1" string, go to next step
             order() # call "order()" function
             break # use "break" function to completely terminate the while loop(1)
        elif(continue_option=="2"): # else if “continue_option" variable is filled in with "2" string, go to next step 
            customer_menu() # "call customer_menu()" function
            break # use "break" function to completely terminate the while loop(1)
        else: # else if "continue_option" variable is not filled in with "1" string or "2" string, go to next step
            print("Please choose valid option!") # display "Please choose valid option!" string to remind customer to choose valid option and restart the while loop(1)

# customer menu option 2   
def order(): # create "order()" function to enable customer to place an order
    print("\n─────────────────Order─────────────────\n") # display "\n─────────────────Order─────────────────\n" string as main topic of "order()" function
    while True: # create while loop(1) with "True" as the condition
        username_input=input("Please enter your username: ") # use “input()” function with "Please enter your username: " string to ask customer to input his username and make it as "username_input" variable
        if username_input=="":  # if "username_input" variable is equal to "" string, go to next step
            print("Please don't blank!")  # display "Please don't blank!" string to remind not to be blank
            continue # use "continue" function to back to the beginning of the while loop(1)
        else:  # else if "username_input" variable is not equal to "" string, go to next step
            with open ("order.txt","a") as order_file: # use "with open ()" function to open "order.txt" for appending and then automatically close the file, make it as "order_file"
                order_file.write("\n{}:".format(username_input))
                # use “write()” function to write "username_input" variable
                # use "str.format()" function to let  "username_input" variable to be written following the format
            break # use "break" function to completely terminate the while loop(1)
    while True: # create while loop(2) with "True" as the condition
        shopping_input=input("What do you want? [Enter <done> to pay]: ") # use “input()” function with "What do you want? [Enter <done> to pay]: " string to ask customer to input what he want and make it as "shopping_input" variable
        if shopping_input=="done": # if “shopping_input" variable is filled in with "done" string, go to next step
            payment() # call "payment()" function
            break # use "break" function to completely terminate the while loop(2)
        elif shopping_input=="": # else if “shopping_input" variable is equal to "" string, go to next step
            print("Please don't blank!") # display "Please don't blank!" string to remind not to be blank and restart the while loop(2)
        else: # else if "shopping_input" variable is not filled in "done" string or "" string, go to next step
            with open ("groceries.txt","r") as read_groceries_file: # use "with open ()" function to open "groceries.txt" for reading and then automatically close the file, make it as "read_groceries_file"
                read=read_groceries_file.read() # use "read()" function to read the all contents of "read_groceries_file" variable at once and make it as "read" variable
                if "name: "+shopping_input+" price: " in read: # if "name: " string + "shopping_input" variable + " price: " string in "read" variable, go to next step
                    while True: # create while loop(3) with "True" as the condition
                        quantity_input=input("How much do you want? : ") # use “input()” function with "How much do you want? : " string to ask customer to input how much he want and make it as "quantity_input" variable
                        if quantity_input!="": # if “quantity_input" variable is not equal to "" string, go to next step
                            with open ("order.txt","a") as order_file: # use "with open ()" function to open "order.txt" for appending and then automatically close the file, make it as "order_file"
                                order_file.write(" {}*{}/".format(shopping_input,quantity_input))
                                # use “write()” function to write "shopping_input" variable and "quantity_input" variable
                                # use "str.format()" function to let  "username_input" variable and "quantity_input" variable to be written following the format
                            break # use "break" function to completely terminate the while loop(3)
                        else: # else if “quantity_input" variable is equal to "" string, go to next step
                            print("Please enter how much do you want.") # display "Please enter how much do you want." string to remind not to be blank and restart the while loop(3)
                else: # else if "name: " string + "shopping_input" variable + " price: " string not in "read" variable, go to next step
                    print("Please enter what we have.") # display "Please enter what we have." string to remind customer to enter what Fresho has and restart the while loop(2)

# pay after order
def payment(): # create "payment()" function to enable customer to pay after order
    print("\n─────────────────Payment─────────────────\n") # display "\n─────────────────Payment─────────────────\n" string as main topic of "payment()" function
    while True: # create while loop(1) with "True" as the condition
        print("Please choose your payment method.") # display "Please choose your payment method." string as topic
        print("(1) >>>>>>>>>> Cash.") # display "(1) >>>>>>>>>> Cash." string as pay by cash selection
        print("(2) >>>>>>>>>> Online Banking.") # display "(2) >>>>>>>>>> Online Banking." string as pay by online banking selection
        payment_option=input("Enter your selection: ") # use “input()” function with "Enter your selection: " string to ask customer to input his selection and make it as "payment_option" variable
        if (payment_option=="1"): # if “payment_option" variable is filled in with "1" string, go to next step
            print("\nThank you for coming. Please pay by cash.") # display "\nThank you for coming. Please pay by cash." string to remind customer to pay for delivery man or pay at the counter
            exit() # call "exit()" function
        elif (payment_option=="2"): # else if “payment_option" variable is filled in with "2" string, go to next step
            while True: # create while loop(2) with "True" as the condition
                banking_account=input("Please enter your account: ") # use “input()” function with "Please enter your account: " string to ask customer to input his online banking account and make it as "banking_account" variable
                if banking_account!="":  # if “banking_account" variable is not equal to "" string, go to next step
                    break # use "break" function to completely terminate the while loop(2)
                else:  # else if “banking_account" variable is equal to "" string, go to next step
                    print("Please enter your account!") # display "Please enter your account!" string to remind not to be blank and restart the while loop(2)
            while True: # create while loop(3) with "True" as the condition
                account_password=input("Please enter your password: ") # use “input()” function with "Please enter your password: " string to ask customer to input his online banking account password and make it as "account_password" variable
                if account_password!="": # if “account_password" variable is not equal to "" string, go to next step
                    print("\nPayment success! Thank you for coming.") # display "\nPayment success! Thank you for coming." string as reminder that succefully paid
                    with open ("order.txt","a") as order_file: # use "with open ()" function to open "order.txt" for appending and then automatically close the file, make it as "order_file"
                        order_file.write(" ~PAID~") # use “write()” function to write " ~PAID~" string
                        exit() # call "exit()" function
                    break # use "break" function to completely terminate the while loop(3)
                else: # else if “account_password" variable is equal to "" string, go to next step
                    print("Please enter your password!") # display "Please enter your password!" string to remind not to be blank and restart the while loop(3)
        else: # else if “payment_option" variable is not filled in with "1" string or "2" string, go to next step
            print("Please choose valid option!") # display "Please choose valid option!" string to remind customer to choose valid option and restart the while loop(1)

# customer menu option 3
def view_own_order(): # create "view_own_order()" function to enable customer to view his order history
    print("\n─────────────────View Own Order─────────────────\n") # display "\n─────────────────View Own Order─────────────────\n" string as main topic of "view_own_order()" function
    while True: # create while loop(1) with "True" as the condition
        customer_username=input("Please enter your username: ") # use “input()” function with "Please enter your username: " string to ask customer to input his username and make it as "customer_username" variable
        with open("customer.txt","r") as read_customer_file: # use "with open ()" function to open "customer.txt" for reading and then automatically close the file, make it as "read_customer_file" variable
            read=read_customer_file.readlines() # use “readlines()” function to read contents of "read_customer_file" variable line by line, put the read contents into a list and then make it as “read” variable
            for line in read: # use for loop and hold the value as "line" variable from "read" variable during the iteration
                if ("username: "+customer_username+"\\") in line: # if "username: " string + "customer_username" variable + "\\" string in "line" variable, go to next step
                    customer_password=input("Please enter your password: ") # use “input()” function with "Please enter your password: " string to ask customer to input his password and make it as "customer_password" variable
                    if ("password: "+customer_password+"\\") in line: # if "password: " string + "customer_password" variable + "\\" string in "line" variable, go to next step
                        print("\nResult:") # display "\nResult:" string
                        with open("order.txt","r") as read_order_file:# use "with open ()" function to open "order.txt" for reading and then automatically close the file, make it as "read_order_file" variable
                                read=read_order_file.readlines() # use “readlines()” function to read contents of "read_order_file" variable line by line, put the read contents into a list and then make it as “read” variable
                        for line in read: # use for loop and hold the value as "line" variable from "read" variable during the iteration
                            if customer_username+":" in line: # if "customer_username" variable + ":" string in "line" variable, go to next step
                                print(line.strip()) # use strip() to remove spaces at the beginning and at the end of "line" variable and then display it
                        customer_menu() # call "customer_menu()" function
                        break # use "break" function to completely terminate the while loop(1)     
            print("Please log in your own account!") # display "Please log in your own account!" string to remind customer to input his correct username and restart the while loop(1)

# customer menu option 4
def view_personal_info(): # create "view_personal_info()" function to enable customer to view their personal information that is written by him on the customer registration
    print("\n─────────────────View Own Profile─────────────────\n") # display "\n─────────────────View Own Profile─────────────────\n" string as main topic of "view_personal_info()" function
    while True: # create while loop(1) with "True" as the condition
        customer_username=input("Please enter your username: ") # use “input()” function with "Please enter your username: " string to ask customer to input his username and make it as "customer_username" variable
        with open("customer.txt","r") as read_customer_file: # use "with open ()" function to open "customer.txt" for reading and then automatically close the file, make it as "read_customer_file" variable
            read=read_customer_file.readlines() # use “readlines()” function to read contents of "read_customer_file" variable line by line, put the read contents into a list and then make it as “read” variable
            for line in read: # use for loop and hold the value as "line" variable from "read" variable during the iteration
                if ("username: "+customer_username+"\\") in line: # if "username: " string + "customer_username" variable + "\\" string in "line" variable, go to next step
                    customer_password=input("Please enter your password: ") # use “input()” function with "Please enter your password: " string to ask customer to input his password and make it as "customer_password" variable
                    if ("password: "+customer_password+"\\") in line: # if "password: " string + "customer_password" variable + "\\" string in "line" variable, go to next step
                            print("\nResult:") # display "\nResult:" string
                            for line in read: # use for loop and hold the value as "line" variable from "read" variable during the iteration
                                if "username: "+customer_username+"\\" in line and "password: "+customer_password+"\\" in line:
                                # if "username: " string + "customer_username" variable + "\\" string and "password: " string + "customer_password" variable + "\\" string in "line" variable, go to next step
                                    print(line) # display "line" variable
                            customer_menu() # call "customer_menu()" function
                            break # use "break" function to completely terminate the while loop(1)
            print("Please log in your own account!") # display "Please log in your own account!" string to remind customer to input his correct username and restart the while loop(1)

# call overall program

# display company name at the beginning
print("\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx") # display "\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" string
print("\n\t\tFRESHO Sdn Bhd\n") # display "\n\t\tFRESHO Sdn Bhd\n" string
print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n") # display "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n" string
        
menu() # call "menu()" function


    
